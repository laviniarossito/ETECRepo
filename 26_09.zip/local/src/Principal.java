
public class Principal {

	public static void main(String[] args) {
		
		//Criar um obejto = Instanciar a classe
		Endereco endereco_1 = new Endereco("RuaUm", "Assis", "SP"); //Par�metro do construtor
		Endereco endereco_2 = new Endereco();
		
		System.out.println(endereco_1.getRua()); //Pegar informa��o
		System.out.println(endereco_1.getCidade()); 
		System.out.println(endereco_1.getEstado()); 
		
		endereco_2.setRua("Rua Luiz");
		endereco_2.setcidade("Londrina");
		
		System.out.println(endereco_2.getRua()); 
		System.out.println(endereco_2.getCidade()); 

	}

}
