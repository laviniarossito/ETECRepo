
public class Endereco {
	
	// Atributos
	private String ruaAt;
	private String cidadeAt;
	private String estadoAt;
	
	// Construtores:
	public Endereco(){
				
	}

	public Endereco(String ruaPar, String cidadePar, String estadoPar){
		
		this.ruaAt = ruaPar;
		this.cidadeAt = cidadePar;
		this.estadoAt = estadoPar;
		
	}
	
	// Setters
	public void setRua(String ruaPar){
		this.ruaAt = ruaPar;
	}
	
	public void setcidade(String ruaPar){
		this.ruaAt = ruaPar;
	}
	
	public void setendereco(String ruaPar){
		this.ruaAt = ruaPar;
	}
	
	//Getters
	public String getRua(){
		return ruaAt.toUpperCase();
	}
	
	public String getCidade(){
		return cidadeAt.toUpperCase();
	}
	
	public String getEstado(){
		return estadoAt.toUpperCase();
	}
}
